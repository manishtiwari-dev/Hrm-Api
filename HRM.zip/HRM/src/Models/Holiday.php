<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use Modules\HRM\Models\LeaveType;

class Holiday extends Model
{
    use HasFactory;

    protected $primaryKey = "id";

    protected $guarded=[
     
        'id',
   
   
       ];

    public function getTable(){
        return config('dbtable.hrm_holidays');
    }


     const DAYS = [
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Friday',
        'Saturday',
        'Sunday'
    ];
    const WEEKDAYS = [
        'Sunday',
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Friday',
        'Saturday'
    ];


}
