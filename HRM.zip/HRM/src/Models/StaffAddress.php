<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Country;

class StaffAddress extends Model
{
    use HasFactory;
    protected $primaryKey = "address_id";
    protected $fillable = [
        'staff_id',
        'address_type',
        'street_address',
        'city',
        'state',
        'postcode',
        'countries_id',
        'phone_no',
    ];
    public $timestamps = false;

    public function getTable(){
        return config('dbtable.hrm_staff_address');
    }
    public function country(){
        return $this->belongsTo(Country::class,'countries_id','countries_id');
    }

}
