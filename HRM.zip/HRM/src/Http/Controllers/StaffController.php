<?php

namespace Modules\HRM\Http\Controllers;

use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use App\Http\Resources\UserResource;
use App\Models\Role;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\SuperUser;
use App\Models\Subscriber;
use App\Models\Subscription;
use App\Models\UserBusiness;
use App\Models\Module;
use App\Models\ModuleSection;
use App\Models\Industry;
use ApiHelper;
use Illuminate\Support\Facades\Storage;
use App\Mail\AutoGeneratePassword;
use Illuminate\Support\Facades\Mail;
use App\Jobs\SendAutoGeneratePasswordMail;
use Illuminate\Support\Facades\Config;
use App\Events\LoginEvent;
use Modules\HRM\Models\Staff;
use Modules\HRM\Models\Education;
use Modules\HRM\Models\Department;
use Modules\HRM\Models\Designation;
use Modules\HRM\Models\Document;
use Modules\HRM\Models\StaffDocument;
use Modules\HRM\Models\StaffWorkExp;
use Modules\HRM\Models\StaffQualification;
use Modules\HRM\Models\StaffAddress;
use Modules\HRM\Models\StaffRemark;
use DB;

use App\Models\Country;


class StaffController extends Controller
{
    public $page = 'staff';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    /* get all userlist */
    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        // return ApiHelper::JSON_RESPONSE(false,ApiHelper::generate_random_token('token',20),'PAGE_ACCESS_DENIED');
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }
        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int)$request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        $user_query = Staff::where('created_by', ApiHelper::get_adminid_from_token($api_token));

        if (!empty($search))
            $user_query = $user_query
                ->where("staff_name", "LIKE", "%{$search}%")
                ->where("staff_email", "LIKE", "%{$search}%")
                ->orWhere("employee_id", "LIKE", "%{$search}%");

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $user_query = $user_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $user_query = $user_query->orderBy('staff_id', 'DESC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;

        $user_count = $user_query->count();

        $user_list = $user_query->skip($skip)->take($perPage)->get();

        $user_list = $user_list->map(function ($user) {


            $user->department_name = $user->department ? $user->department->dept_name : '';
            $user->designation_name = $user->designation ? $user->designation->designation_name : '';

            $user->staff_photo = ApiHelper::getFullImageUrl($user->staff_photo);

            return $user;
        });

        $res = [
            'data' => $user_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create(Request $request)
    {
        $res = [];
        $api_token = $request->api_token;
        //   $res['user_list'] = User::where('created_by',ApiHelper::get_adminid_from_token($api_token))->get();
        $res['department_list'] = Department::where('created_by', ApiHelper::get_adminid_from_token($api_token))
            ->get();
        $res['designation_list'] = Designation::where('created_by', ApiHelper::get_adminid_from_token($api_token))
            ->get();
        $res['role_list'] = Role::all();
        $res['user_list'] = User::all();
        $res['country_list'] = Country::all();
        $res['education_list'] = Education::where('status', 1)->get();
        $res['document_list'] = Document::where('status', 1)->get();
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /* create user and assign role  */
    public function store(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        // validation check
        $rules = [
            'email' => 'required|string|email|max:255',
        ];
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email|max:255',
        ], [
            'email.required' => 'EMAIL_REQUIRED',
        ]);
        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }

        try {

            DB::beginTransaction();
            if ($request->user_type == 'new') {
                $user = User::where('email', $request->email)->first();
                if ($user === null) {

                    $user = User::create([
                        'first_name' => $request->name,
                        'last_name' => '',
                        'email' => $request->email,
                        'password' => 'test',
                        'created_by' => 1,
                        'api_token' => Hash::make($request->name),
                    ]);


                    return ApiHelper::JSON_RESPONSE(false, [], $user);
                    // attach role
                    $user->roles()->attach($request->role_name);
                }
            } else {
                $user = User::find($request->user_id);
            }

            $staffDetails = Staff::where('user_id', $user->id)->first();
            if ($staffDetails != null) {
                return ApiHelper::JSON_RESPONSE(false, [], 'ALREADY_STAFF_EXIST_FOR_THIS_USER');
            } else {

                $imageData = $request->fileInfo;
                $extension = pathinfo($imageData, PATHINFO_EXTENSION);

                $file_name = 'profile' . rand(999, 9999) . '.' . $extension;

                Storage::disk('public')->put($file_name, $imageData);
                $wDocPath = asset('/' . $file_name);

                $url = Storage::path($imageData);



                $staff = Staff::create([
                    'employee_id' => 'emp' . ApiHelper::generate_random_token('numeric', 6),
                    'user_id' => $user->id,
                    'department_id' => $request->department_id,
                    'designation_id' => $request->designation_id,
                    'gender' => $request->gender,
                    'staff_name' => $user->first_name,

                    'staff_photo' => $url ?? '',

                    'staff_email' => $user->email,
                    'staff_phone' => $request->phone_no,
                    'date_of_joining' => $request->staff_date_of_joining ?? '',
                    'date_of_leaving' => $request->staff_date_of_joining ?? '',
                    'marital_status' => $request->marital_status,
                    'date_of_birth' => $request->date_of_birth,
                    'verification_status' => 2,
                    'salary' => 0.0,
                    'created_by' => ApiHelper::get_adminid_from_token($request->api_token),
                    'updated_by' => ApiHelper::get_adminid_from_token($request->api_token),
                ]);

                $staffAddress = StaffAddress::create([
                    'staff_id' => $staff->staff_id,
                    'address_type' => 1,
                    'street_address' => $request->street_address,
                    'city' => $request->city,
                    'state' => $request->state,
                    'postcode' => $request->postcode,
                    'countries_id' => $request->countries_id,
                    'phone_no' => $request->phone_no,
                ]);

                // store present address
                if ($request->address_type) {
                    StaffAddress::create([
                        'staff_id' => $staff->staff_id,
                        'address_type' => 2,
                        'street_address' => $request->permanent_street_address,
                        'city' => $request->permanent_city,
                        'state' => $request->permanent_state,
                        'postcode' => $request->permanent_postcode,
                        'countries_id' => $request->permanent_countries_id,
                        'phone_no' => $request->permanent_phone_no,
                    ]);
                    return ApiHelper::JSON_RESPONSE(true, [], $request->address_type);
                } else {
                    $presentAdd = $staffAddress->replicate()->fill([
                        'address_type' => 2,
                    ]);
                    $presentAdd->save();
                }



                if (sizeof($request->company_name) > 0) {

                    foreach ($request->company_name as $key => $work) {
                        $doc_id = 0;
                        $wDocs = $request->work_document[$key];

                        // if(!empty($wDocs)){  

                        // $docWork = str_replace("tempfolder", "StaffWorkExp", $wDocs); 
                        // Storage::move($workDoc, $imgNewLoc );




                        // $imgNewLoc = str_replace("tempfolder", "StaffWorkExp", $request->work_document[$key] ?? ''); 
                        // Storage::move($request->work_document[$key], $imgNewLoc );
                        // $res = StaffDocument::create([
                        //     'document_id'=>$request->work_document_type[$key],
                        //     'document_file'=>$imgNewLoc,
                        //     'staff_id'=>$staff->staff_id,
                        // ]); 
                        // $doc_id = $res->staff_doc_id;
                        // }

                        StaffWorkExp::create([
                            'company_name' => $request->company_designation[$key] ?? '',
                            'company_designation' => $request->company_designation[$key] ?? '',
                            'company_address' => $request->company_address[$key] ?? '',
                            'contact_name' => $request->contact_name[$key] ?? '',
                            'contact_email' => $request->contact_email[$key] ?? '',
                            'contact_phone' => $request->contact_phone[$key] ?? '',
                            'date_of_joining' => $request->work_date_of_joining[$key] ?? '',
                            'date_of_leaving' => $request->work_date_of_leaving[$key] ?? '',
                            'reason_for_leaving' => $request->reason_for_leaving[$key] ?? '',
                            'staff_doc_id' => $doc_id,
                            'staff_id' => $staff->staff_id,
                        ]);
                    }
                }

                $education_id = $request->education_id ? $request->education_id : 0;
                $university_name = $request->university_name ? $request->university_name : 0;
                $admission_at = $request->admission_at ? $request->admission_at : 0;
                $passing_at = $request->passing_at ? $request->passing_at : 0;
                $education_document_type = $request->education_document_type ? $request->education_document_type : 0;
                $education_document = $request->education_document ? $request->education_document : 0;

                foreach ($education_id as $key => $value) {

                    $doc_id = 0;
                    if (empty($education_document[$key])) {
                        $imgNewLoc = str_replace("tempfolder", "StaffEducation", $request->education_document[$key] ?? 0);

                        Storage::move($request->education_document[$key] ?? 0, $imgNewLoc);
                        $res = StaffDocument::create([
                            'document_id' => $request->education_document_type[$key] ?? 0,
                            'document_file' => $imgNewLoc,
                            'staff_id' => $staff->staff_id,
                        ]);
                        $doc_id = $res->staff_doc_id;
                    }

                    StaffQualification::create([
                        'staff_id' => $staff->staff_id,
                        'university_name' => $request->university_name[$key] ?? 0,
                        'education_id' => $value ?? 0,
                        'admission_at' => $request->admission_at[$key] ?? 0,
                        'passing_at' => $request->passing_at[$key] ?? 0,
                        'staff_doc_id' => $doc_id,
                    ]);
                }
                DB::commit();       // db commit 
                // return ApiHelper::JSON_RESPONSE(true,[],$user);
                return ApiHelper::JSON_RESPONSE(true, $user, 'SUCCESS_STAFF_ADD');
            }
        } catch (\Throwable $th) {
            \Log::error($th->getMessage());
            DB::rollback();     // db rollback
            return ApiHelper::JSON_RESPONSE(false, [], json_encode($th->getMessage()));
        }
    }

    public function edit(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $staff_details = Staff::find($request->staff_id);

        if ($staff_details != null) {

            $staff_details->staff_photo =
                !empty($staff_details->staff_photo) ? Storage::url($staff_details->staff_photo) : '';

            $staff_details->user = $staff_details->user;
            $staff_details->department = $staff_details->department;
            $staff_details->designation = $staff_details->designation;
            $staff_details->staff_address = $staff_details->staff_address;
            if (!empty($staff_details->staff_address)) {
                $staff_details->staff_address = $staff_details->staff_address->map(function ($address) {
                    $address->country = $address->country;
                    return $address;
                });
            }

            $staff_details->staff_document = $staff_details->staff_document;
            if (!empty($staff_details->staff_document)) {
                $staff_details->staff_document = $staff_details->staff_document->map(function ($doc) {
                    $doc->document_file = !empty($doc->document_file) ? Storage::url($doc->document_file) : '';
                    $doc->document_file_name = isset($doc->doc_info) ? $doc->doc_info->document_name : '';
                    $doc->document_file_type = (strpos($doc->document_file, ".png") || strpos($doc->document_file, ".jpg") || strpos($doc->document_file, ".gif")) ? 'image' : 'other';
                    return $doc;
                });
            }

            $staff_details->staff_qualification = $staff_details->staff_qualification;

            if (!empty($staff_details->staff_qualification)) {
                $staff_details->staff_qualification = $staff_details->staff_qualification->map(function ($quali) {
                    $quali->education = $quali->education;
                    return $quali;
                });
            }

            $staff_details->staff_experiance = $staff_details->staff_experiance;

            $document = Document::all();
            $designation = Designation::all();
            $department = Department::all();
            $country = Country::all();
            $education = Education::all();
            $res = [
                'staff_details' => $staff_details,
                'documentation' => $document,
                'designation' => $designation,
                'department' => $department,
                'country' => $country,
                'education' => $education,
            ];


            return ApiHelper::JSON_RESPONSE(true, $res, '');
        } else
            return ApiHelper::JSON_RESPONSE(false, [], 'SOMETHING_WRONG');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        $staff_id = $request->staff_id;
        $sectionName = $request->updateSection;

        switch ($sectionName) {
            case 'workexp':

                $doc_id = 0;
                if (!empty($request->document)) {
                    $imgNewLoc = str_replace("tempfolder", "StaffWorkExp", $request->document);
                    Storage::move($request->document, $imgNewLoc);
                    $res = StaffDocument::create(['document_id' => $request->document_type, 'document_file' => $imgNewLoc, 'staff_id' => $staff_id]);
                    $doc_id = $res->staff_doc_id;
                }

                $expdata = $request->only([
                    'company_name', 'company_designation', 'company_address', 'contact_name', 'contact_email', 'contact_phone', 'date_of_joining', 'date_of_leaving', 'reason_for_leaving', 'staff_id',
                ]);
                $expdata['staff_doc_id'] = $doc_id;

                $status =  ($request->updateType == 'new')
                    ? StaffWorkExp::create($expdata)
                    : StaffWorkExp::where('experience_id', $request->experience_id)->update($expdata);
                break;

            case 'education':

                $doc_id = 0;
                if (!empty($request->document)) {
                    $imgNewLoc = str_replace("tempfolder", "StaffEducation", $request->document);
                    Storage::move($request->document, $imgNewLoc);
                    $res = StaffDocument::create(['document_id' => $request->document_type, 'document_file' => $imgNewLoc, 'staff_id' => $staff_id]);
                    $doc_id = $res->staff_doc_id;
                }

                $expdata = $request->only(['staff_id', 'education_id', 'university_name', 'admission_at', 'passing_at']);
                $expdata['staff_doc_id'] = $doc_id;

                $status = ($request->updateType == 'new')
                    ? StaffQualification::create($expdata)
                    : StaffQualification::where('qualification_id', $request->qualification_id)->update($expdata);
                break;

            case 'basic_info':

                $expdata = $request->except(['updateSection', 'api_token']);

                $status = Staff::where('staff_id', $staff_id)->update($expdata);

                break;

            case 'address':
                $expdata = $request->except(['updateSection', 'updateType', 'api_token']);
                $status = StaffAddress::where('address_id', $request->address_id)->update($expdata);

                break;

            case 'ProfileImageUpdate':
                $filename = $request->file('fileInfo')->store("profile");
                $status = Staff::where('staff_id', $staff_id)->update(['staff_photo' => $filename]);
                break;

            default:
                $status = false;
                break;
        }
        if ($status)
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_STAFF_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(true, [], 'ERROR_STAFF_UPDATE');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function changeStatus(Request $request)
    {
        $api_token = $request->api_token;
        $staff_id = $request->staff_id;
        $type = $request->type;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pagestatus))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $staff = Staff::find($staff_id);

        if ($type == 'verification') {
            $staff->verification_status  = $staff->verification_status == 0 ? 1 : 0;
        } else {
            if ($staff->status == 1) {
                $staff->status  = 2;
                $staff->termination_reason = $request->termination_reason;

                StaffRemark::create([
                    'staff_id' => $staff_id,
                    'remark_type' => 4,
                    'remark_grade' => 0,
                    'remark_details' => $request->remark_details,
                    'updated_at' => date('Y-m-d'),
                ]);
            } else {
                $staff->status  = 1;
            }
        }

        $status = $staff->save();
        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_STATUS_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_STATUS_UPDATE');
        }
    }

    public function verification(Request $request)
    {
        $api_token = $request->api_token;
        $staff_id = $request->staff_id;
        // $remark_id= $request->remark_id;
        // $type = $request->type;

        // if(!ApiHelper::is_page_access($api_token, $this->page, $this->pagestatus))
        //     return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        // $staff = Staff::find($staff_id);

        $staffRemark = StaffRemark::create([
            'remark_details' => $request->remark_details,
            'staff_id' => $request->staff_id,
        ]);


        $staff = Staff::where('staff_id', $staff_id)->update([
            'verified_by' =>  $staffRemark->remark_id,
            'verified_at' => date('Y-m-d'),
        ]);

        $staffRemark = $staff;

        if ($staffRemark) {
            return ApiHelper::JSON_RESPONSE(true, $staffRemark, 'SUCCESS_VERIFICATION_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_VERIFICATION_UPDATE');
        }
    }

    public function terminate(Request $request)
    {
        $api_token = $request->api_token;
        $staff_id = $request->staff_id;
        $staffRemark = StaffRemark::create([
            'remark_details' => $request->remark_details,
            'staff_id' => $request->staff_id,
        ]);

        $staff = Staff::find($staff_id);

        $staff->termination_reason = $request->termination_reason;
        $staff->date_of_leaving = $request->date_of_leaving;
        $staff->rehire = $request->rehire;

        $staffRemark = $staff->save();
        if ($staffRemark) {
            return ApiHelper::JSON_RESPONSE(true, $staffRemark, 'SUCCESS_TERMINATE_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_TERMINATE_UPDATE');
        }
    }
}
