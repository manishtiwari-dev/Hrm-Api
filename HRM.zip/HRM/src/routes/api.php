<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Modules\HRM\Http\Controllers\DepartmentController;
use Modules\HRM\Http\Controllers\DesignationController;
use Modules\HRM\Http\Controllers\LeaveController;
use Modules\HRM\Http\Controllers\LeaveTypeController;
use Modules\HRM\Http\Controllers\AttendanceController;
use Modules\HRM\Http\Controllers\StaffController;
use Modules\HRM\Http\Controllers\HolidayController;



/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['middleware' => ['ApiTokenCheck'], 'prefix' => "api/"], function () {

    //Department API
    Route::group(['prefix' => 'department'], function () {
        Route::post('/all', [DepartmentController::class, 'index_all']);
        Route::post('/', [DepartmentController::class, 'index']);
        Route::post('/store', [DepartmentController::class, 'store']);
        Route::post('/edit', [DepartmentController::class, 'edit']);
        Route::post('/update', [DepartmentController::class, 'update']);
        Route::post('/delete', [DepartmentController::class, 'destroy']);
        Route::post('/changeStatus', [DepartmentController::class, 'changeStatus']);
    });
    //end Department API

    //Designation API
    Route::group(['prefix' => 'designation'], function () {
        Route::post('/all', [DesignationController::class, 'index_all']);
        Route::post('/', [DesignationController::class, 'index']);
        Route::post('/store', [DesignationController::class, 'store']);
        Route::post('/edit', [DesignationController::class, 'edit']);
        Route::post('/update', [DesignationController::class, 'update']);
        Route::post('/delete', [DesignationController::class, 'destroy']);
        Route::post('/changeStatus', [DesignationController::class, 'changeStatus']);
    });

    //end Designation API

    //LeaveType API
    Route::group(['prefix' => 'leaveType'], function () {
        Route::post('/', [LeaveTypeController::class, 'index']);
        Route::post('/store', [LeaveTypeController::class, 'store']);
        Route::post('/edit', [LeaveTypeController::class, 'edit']);
        Route::post('/update', [LeaveTypeController::class, 'update']);
        Route::post('/delete', [LeaveTypeController::class, 'destroy']);
    });
    //end LeaveType API

    //Leave API
    Route::group(['prefix' => 'leave'], function () {
        Route::post('/', [LeaveController::class, 'index']);
        Route::post('/store', [LeaveController::class, 'store']);
        Route::post('/create', [LeaveController::class,'create']);
        Route::post('/edit', [LeaveController::class, 'edit']);
        Route::post('/update', [LeaveController::class, 'update']);
        Route::post('/status', [LeaveController::class, 'statusChange']);
    });
    //end Leave API

    //Staff API
    Route::group(['prefix' => 'staff'], function () {
        Route::post('/', [StaffController::class, 'index']);
        Route::post('/create', [StaffController::class, 'create']);
        Route::post('/store', [StaffController::class, 'store']);
        Route::post('/edit', [StaffController::class, 'edit']);
        Route::post('/update', [StaffController::class, 'update']);
        Route::post('/changeStatus', [StaffController::class, 'changeStatus']);
        Route::post('/verify', [StaffController::class, 'verification']);
        Route::post('/terminate', [StaffController::class, 'terminate']);
    });
    //end Staff API

    //Attendence API
    Route::group(['prefix' => 'attendance'], function () {
        Route::post('/', [AttendanceController::class, 'index']);
        Route::post('/create', [AttendanceController::class, 'create']);
        Route::post('/check-in', [AttendanceController::class, 'checkIn']);
        Route::post('/check-out', [AttendanceController::class, 'checkOut']);
        Route::post('/select_dept', [AttendanceController::class, 'select_dept']);
        Route::post('/attend-data', [AttendanceController::class, 'attendData']);
    });

    //end Attendence API


    //start holyday 
    Route::group(['prefix' => 'holyday'], function () {
        Route::post('/', [HolidayController::class, 'index']);
        Route::post('/store', [HolidayController::class, 'store']);
        Route::post('/create', [HolidayController::class, 'create']);
        Route::post('/edit', [HolidayController::class, 'edit']);
        Route::post('/update', [HolidayController::class, 'update']);
        Route::post('/delete', [HolidayController::class, 'destroy']);
        Route::post('/markDayHoliday', [HolidayController::class, 'markDayHoliday']);
    });
    //end holyday

});
